I included two images for the serial execution of the monte carlo code.

The first ("1 thread") uses all of the regular code, except with thread num set to 1

The "serial run" of the code uses no concurrent code except to get the approx. time it took to run.