#include "mul_dis.h"

int mul(int a, int b) {
    return a * b;
}

double dis(int a, int b) {
    return a * 1.0 / b;
}
