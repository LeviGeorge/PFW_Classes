#ifndef ADD_SUB_H_
#define ADD_SUB_H_

int add(int a, int b);
int sub(int a, int b);

#endif // ADD_SUB_H_