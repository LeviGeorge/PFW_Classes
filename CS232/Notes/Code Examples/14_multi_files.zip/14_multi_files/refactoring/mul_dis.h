#ifndef MUL_DIS_H_
#define MUL_DIS_H_

int mul(int a, int b);
double dis(int a, int b);

#endif // MUL_DIS_H_
