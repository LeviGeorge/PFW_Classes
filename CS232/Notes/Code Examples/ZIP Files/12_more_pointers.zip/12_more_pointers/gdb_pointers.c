#include <stdio.h>

int main() {
    int x = 100;
    int *pInt = &x;
    int y[5] = {1, 2, 3, 4, 5};
    char *pChar = "This is a string.";
    
    return 0;
}
